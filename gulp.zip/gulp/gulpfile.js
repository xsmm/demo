var gulp = require('gulp');
var uglify = require('gulp-uglify');
var sourcemaps = require('gulp-sourcemaps');
var sass = require('gulp-ruby-sass');
var imagemin = require('gulp-imagemin'), // 图片压缩
    pngquant = require('imagemin-pngquant'); // 深度压缩
var concat = require("gulp-concat"); // 文件合并


//html文件引入
gulp.task('html', function() {
  return gulp.src('index.html') // 指明源文件路径、并进行文件匹配
      .pipe(gulp.dest('dist')); // 输出路径
});
// gulp.task('min-js', function (argument) {
//   // body...
//   return gulp.src('js/*.js').pipe(uglify()).pipe(gulp.dest('dist/js'));
// });
//用时最短
//gulp.task('default',[min-js]);
// gulp.task('default',function () {
//   gulp.run('min-js')
// })
//js文件压缩
gulp.task('script', function() {
  return gulp.src(['js/*.js']) // 指明源文件路径、并进行文件匹配，排除 .min.js 后缀的文件
      .pipe(sourcemaps.init()) // 执行sourcemaps
      .pipe(uglify()) // 使用uglify进行压缩，并保留部分注释
      .pipe(sourcemaps.write('/map')) // 地图输出路径（存放位置）
      .pipe(gulp.dest('dist/js1')); // 输出路径
});
//css文件压缩
gulp.task('sass', function () {
  return sass('css/*.css', { style: 'compressed' }) // 指明源文件路径、并进行文件匹配（style: 'compressed' 表示输出格式）
      .on('error', function (err) {
        console.error('Error!', err.message); // 显示错误信息
      })
      .pipe(gulp.dest('dist/css')); // 输出路径
});
//图片压缩
gulp.task('images', function(){
  return gulp.src('img/*.{png,jpg,gif,svg}') // 指明源文件路径、并进行文件匹配
      .pipe(imagemin({
        progressive: true, // 无损压缩JPG图片
        svgoPlugins: [{removeViewBox: false}], // 不移除svg的viewbox属性
        use: [pngquant()] // 使用pngquant插件进行深度压缩
      }))
      .pipe(gulp.dest('dist/images')); // 输出路径
});
//js文件合并
gulp.task('concat', function () {
  gulp.src(['js/*.js'])  // 要合并的文件
      .pipe(concat('libs.js'))  // 合并成libs.js
      .pipe(gulp.dest('dist/js'));
});
//css文件合并
gulp.task('concatcss', function () {
  gulp.src(['css/*.css'])  // 要合并的文件
      .pipe(concat('libs.css'))  // 合并成libs.css
      .pipe(gulp.dest('dist/css1'));
});
gulp.task('concatcss1', function () {
  gulp.src(['dist/css/*.css'])  // 要合并的文件
      .pipe(concat('libs1.css'))  // 合并成libs.css
      .pipe(gulp.dest('dist/css2'));
});
gulp.task('default',['html','script','concat','images','concatcss']);